"use strict";

(function () {
    const S = SantaBuscaStorage;
    const establishment = S.getCurrentEstablishment();

    if (!establishment) {
        window.location.href = "estabelecimento.html";
        return;
    }

    const $ = (id) => document.getElementById(id);

    let editingProduct = null;

    function showMessage(id, message, type = "success") {
        const element = $(id);
        element.textContent = message;
        element.classList.toggle("errorMessage", type === "error");
    }

    function parseDecimal(value, allowNegative = false) {
        const sanitized = S.sanitizeDecimal(
            value,
            allowNegative
        );

        if (sanitized === "" || sanitized === "-" || sanitized === ".") {
            return NaN;
        }

        return Number(sanitized);
    }

    function setupDecimalInput(input) {
        if (!input) {
            return;
        }

        input.addEventListener("input", () => {
            input.value = S.sanitizeDecimal(
                input.value,
                input.dataset.negative === "true"
            );
        });

        input.addEventListener("blur", () => {
            const value = parseDecimal(
                input.value,
                input.dataset.negative === "true"
            );

            if (Number.isFinite(value)) {
                input.value = value.toFixed(2).replace(/\.00$/, "");
            }
        });
    }

    function setupCoordinateInput(input) {
        if (!input) {
            return;
        }

        input.addEventListener("input", () => {
            input.value = input.value
                .split(",")
                .slice(0, 2)
                .map((part) => S.sanitizeDecimal(part, true))
                .join(", ");
        });

        input.addEventListener("blur", () => {
            input.value = input.value
                .split(",")
                .slice(0, 2)
                .map((part) => S.sanitizeDecimal(part, true).trim())
                .join(", ");
        });
    }

    function setupCNPJInput(input) {
        if (!input) {
            return;
        }

        const update = () => {
            S.reformatKeepingCaret(input, S.formatCNPJ);
            $("edit-cnpj-field").classList.toggle(
                "field-error",
                input.value !== "" &&
                !S.validateCNPJ(input.value)
            );
        };

        input.addEventListener("input", update);

        input.addEventListener("blur", () => {
            input.value = S.formatCNPJ(input.value);
            $("edit-cnpj-field").classList.toggle(
                "field-error",
                !S.validateCNPJ(input.value)
            );
        });
    }

    function fillEstablishment() {
        $("dash-name").textContent =
            establishment.nome || "Meu estabelecimento";

        $("edit-email").value =
            establishment.email || "";

        $("edit-nome").value =
            establishment.nome || "";

        $("edit-cnpj").value =
            S.formatCNPJ(establishment.cnpj || "");

        $("edit-endereco").value =
            establishment.endereco || "";

        $("edit-coord").value =
            establishment.coordenadas || "";

        $("edit-tipo").value =
            establishment.tipo || "comercio";

        $("edit-abertura").value =
            establishment.abertura || "";

        $("edit-fechamento").value =
            establishment.fechamento || "";

        $("edit-dias").value =
            Array.isArray(establishment.dias)
                ? establishment.dias.join(", ")
                : establishment.dias || "";

        renderImages();
    }

    function readImage(file) {
        return new Promise((resolve, reject) => {
            if (!file) {
                resolve(null);
                return;
            }

            const reader = new FileReader();

            reader.onerror = () =>
                reject(
                    new Error("Não foi possível ler a imagem.")
                );

            reader.onload = (event) =>
                resolve(event.target.result);

            reader.readAsDataURL(file);
        });
    }

    function renderImages() {
        const container = $("current-images");
        const items = [];

        if (establishment.logo) {
            items.push(`
                <div>
                    <small>Logotipo atual</small>
                    <img src="${establishment.logo}" alt="Logotipo atual">
                </div>
            `);
        }

        if (establishment.foto) {
            items.push(`
                <div>
                    <small>Foto atual</small>
                    <img src="${establishment.foto}" alt="Foto atual">
                </div>
            `);
        }

        container.innerHTML = items.join("");
    }

    function getMyProducts() {
        return S.getEstablishmentProducts(
            establishment
        );
    }

    function getProductKey(product) {
        return product.chave || S.priceKey(
            product.nome,
            product.marca,
            establishment.nome
        );
    }

    function renderProducts() {
        const products = getMyProducts();
        const container = $("my-products");

        if (!products.length) {
            container.innerHTML = `
                <div class="mutedBox">
                    Este estabelecimento ainda não possui produtos cadastrados.
                    Use "Cadastrar produto" para adicionar o primeiro.
                </div>
            `;
            return;
        }

        container.innerHTML = products
            .map((product) => {
                const price = Number(
                    product.preco
                );

                return `
                    <article class="dashboardListItem">
                        <div>
                            <strong>
                                ${escapeHTML(product.emoji || "📦")}
                                ${escapeHTML(product.nome)}
                            </strong>
                            <small>
                                ${escapeHTML(product.marca || "Sem marca")}
                                · ${escapeHTML(product.unidade || "unidade")}
                            </small>
                            <small>
                                ${Number.isFinite(price)
                                    ? formatPrice(price)
                                    : "Preço não informado"}
                                · ${
                                    product.disponibilidade === "esgotado"
                                        ? "Esgotado"
                                        : "Disponível"
                                }
                            </small>
                        </div>

                        <div class="dashboardListActions">
                            <button
                                class="miniAction"
                                type="button"
                                data-edit-product="${escapeHTML(product.id)}"
                            >
                                Editar
                            </button>

                            <button
                                class="miniAction dangerBtn"
                                type="button"
                                data-delete-product="${escapeHTML(product.id)}"
                            >
                                Excluir
                            </button>
                        </div>
                    </article>
                `;
            })
            .join("");
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(
            /[&<>"']/g,
            (character) => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[character])
        );
    }

    function formatPrice(value) {
        return new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL"
        }).format(Number(value));
    }

    function openProductForm(product = null) {
        editingProduct = product;

        $("product-form-wrap").hidden = false;
        $("product-form-title").textContent =
            product
                ? "Editar produto"
                : "Cadastrar produto";

        $("product-id").value =
            product && !product.origemCatalogo
                ? product.id
                : "";

        $("product-name").value =
            product?.nome || "";

        $("product-brand").value =
            product?.marca || "";

        $("product-category").value =
            product?.categoria || "Supermercados";

        $("product-unit").value =
            product?.unidade || "unidade";

        $("product-price").value =
            Number.isFinite(Number(product?.preco))
                ? String(product.preco).replace(".", ",")
                : "";

        $("product-emoji").value =
            product?.emoji || "";

        $("product-availability").value =
            product?.disponibilidade || "disponivel";

        $("product-msg").textContent = "";
        $("product-name").focus();
    }

    function closeProductForm() {
        editingProduct = null;
        $("product-form").reset();
        $("product-id").value = "";
        $("product-category").value = "Supermercados";
        $("product-availability").value = "disponivel";
        $("product-form-wrap").hidden = true;
    }

    function populateProductSelectors() {
        const products = getMyProducts();

        const productOptions = products
            .map(
                (product, index) => `
                    <option value="${index}">
                        ${escapeHTML(product.nome)}
                        · ${escapeHTML(product.marca)}
                    </option>
                `
            )
            .join("");

        $("offer-product").innerHTML =
            productOptions ||
            '<option value="">Nenhum produto cadastrado</option>';

        $("price-product").innerHTML =
            productOptions ||
            '<option value="">Nenhum produto cadastrado</option>';

        populateBrandSelector(
            "offer-product",
            "offer-brand"
        );

        populateBrandSelector(
            "price-product",
            "price-brand"
        );
    }

    function populateBrandSelector(
        productSelectId,
        brandSelectId
    ) {
        const products = getMyProducts();
        const select = $(productSelectId);
        const brandSelect = $(brandSelectId);
        const selected = products[Number(select.value)];

        if (!selected) {
            brandSelect.innerHTML =
                '<option value="">Nenhuma marca</option>';
            return;
        }

        brandSelect.innerHTML = `
            <option value="${escapeHTML(selected.id)}">
                ${escapeHTML(selected.marca)}
            </option>
        `;
    }

    function selectedProduct(productSelectId) {
        const products = getMyProducts();
        return products[Number($(productSelectId).value)] || null;
    }

    $("form-edit").onsubmit = async (event) => {
        event.preventDefault();

        const name = $("edit-nome").value.trim();
        const cnpj = $("edit-cnpj").value.trim();
        const address = $("edit-endereco").value.trim();
        const coordinates = $("edit-coord").value.trim();
        const opening = $("edit-abertura").value;
        const closing = $("edit-fechamento").value;
        const days = $("edit-dias").value
            .split(",")
            .map((day) => day.trim())
            .filter(Boolean);

        const valid =
            Boolean(name) &&
            Boolean(address) &&
            S.validateCNPJ(cnpj) &&
            S.isValidCoordinatePair(coordinates) &&
            Boolean(opening) &&
            Boolean(closing) &&
            days.length > 0;

        $("edit-cnpj-field").classList.toggle(
            "field-error",
            !S.validateCNPJ(cnpj)
        );

        if (!valid) {
            showMessage(
                "edit-alert",
                "Preencha nome, CNPJ, endereço, localização e horários corretamente.",
                "error"
            );
            $("edit-alert").classList.add("visible");
            return;
        }

        let logo = establishment.logo;
        let foto = establishment.foto;

        try {
            const newLogo = await readImage(
                $("edit-logo").files?.[0]
            );

            const newFoto = await readImage(
                $("edit-foto").files?.[0]
            );

            if (newLogo) {
                logo = newLogo;
            }

            if (newFoto) {
                foto = newFoto;
            }
        } catch (error) {
            showMessage(
                "edit-alert",
                error.message,
                "error"
            );
            $("edit-alert").classList.add("visible");
            return;
        }

        const updated = S.saveEstablishment({
            ...establishment,
            nome: name,
            cnpj: S.formatCNPJ(cnpj),
            endereco: address,
            coordenadas: coordinates,
            abertura: opening,
            fechamento: closing,
            dias: days,
            tipo: $("edit-tipo").value,
            logo,
            foto
        });

        Object.assign(establishment, updated);

        $("edit-logo").value = "";
        $("edit-foto").value = "";

        fillEstablishment();
        renderProducts();
        populateProductSelectors();

        showMessage(
            "edit-alert",
            "Dados atualizados com sucesso."
        );
        $("edit-alert").classList.add("visible");
    };

    $("new-product").onclick = () =>
        openProductForm();

    $("product-cancel").onclick = closeProductForm;

    $("product-form").onsubmit = (event) => {
        event.preventDefault();

        const name = $("product-name").value.trim();
        const brand = $("product-brand").value.trim();
        const category = $("product-category").value;
        const unit = $("product-unit").value.trim() || "unidade";
        const price = parseDecimal(
            $("product-price").value
        );
        const emoji = $("product-emoji").value.trim();
        const availability =
            $("product-availability").value;

        if (
            !name ||
            !brand ||
            !category ||
            !Number.isFinite(price) ||
            price < 0 ||
            !unit
        ) {
            showMessage(
                "product-msg",
                "Preencha nome, marca, categoria, unidade e um preço válido.",
                "error"
            );
            return;
        }

        const oldProduct = editingProduct;
        const isCatalogProduct =
            Boolean(oldProduct?.origemCatalogo);

        const product = {
            ...(oldProduct || {}),
            id:
                $("product-id").value ||
                (isCatalogProduct
                    ? undefined
                    : oldProduct?.id),
            estabelecimentoId: establishment.id,
            estabelecimento: establishment.nome,
            nome: name,
            marca: brand,
            categoria: category,
            unidade: unit,
            preco: price,
            emoji: emoji || "📦",
            disponibilidade: availability,
            chave: S.priceKey(
                name,
                brand,
                establishment.nome
            )
        };

        S.saveProduct(product);

        if (
            oldProduct &&
            getProductKey(oldProduct) !== product.chave
        ) {
            S.deleteProduct(
                oldProduct.id,
                oldProduct
            );
        }

        closeProductForm();
        renderProducts();
        populateProductSelectors();

        showMessage(
            "product-msg",
            "Produto salvo com sucesso."
        );
    };

    $("my-products").addEventListener(
        "click",
        (event) => {
            const editButton =
                event.target.closest(
                    "[data-edit-product]"
                );

            if (editButton) {
                const product = getMyProducts().find(
                    (item) =>
                        String(item.id) ===
                        String(
                            editButton.dataset.editProduct
                        )
                );

                if (product) {
                    openProductForm(product);
                }

                return;
            }

            const deleteButton =
                event.target.closest(
                    "[data-delete-product]"
                );

            if (deleteButton) {
                const product = getMyProducts().find(
                    (item) =>
                        String(item.id) ===
                        String(
                            deleteButton.dataset.deleteProduct
                        )
                );

                if (!product) {
                    return;
                }

                if (
                    !window.confirm(
                        `Excluir o produto "${product.nome}" deste estabelecimento?`
                    )
                ) {
                    return;
                }

                S.deleteProduct(
                    product.id,
                    product
                );

                renderProducts();
                populateProductSelectors();
            }
        }
    );

    $("offer-product").onchange = () =>
        populateBrandSelector(
            "offer-product",
            "offer-brand"
        );

    $("price-product").onchange = () =>
        populateBrandSelector(
            "price-product",
            "price-brand"
        );

    $("offer-form").onsubmit = (event) => {
        event.preventDefault();

        const product = selectedProduct(
            "offer-product"
        );
        const price = parseDecimal(
            $("offer-price").value
        );
        const end = $("offer-fim").value;

        if (
            !product ||
            !Number.isFinite(price) ||
            price < 0 ||
            !end
        ) {
            showMessage(
                "offer-msg",
                "Preencha produto, preço e validade da oferta.",
                "error"
            );
            return;
        }

        const key = getProductKey(product);

        S.saveOffer({
            chave: key,
            produto: product.nome,
            marca: product.marca,
            estabelecimento: establishment.nome,
            preco: price,
            inicio: new Date().toISOString(),
            fim: new Date(end).toISOString(),
            criadaPor: establishment.id
        });

        showMessage(
            "offer-msg",
            "Oferta publicada com sucesso."
        );

        $("offer-edit-key").value = "";
        $("offer-price").value = "";
        $("offer-fim").value = "";

        renderOffers();
    };

    $("offer-cancel").onclick = () => {
        $("offer-form").reset();
        $("offer-edit-key").value = "";
    };

    function renderOffers() {
        const offers =
            S.getOffersForEstablishment(
                establishment
            );

        if (!offers.length) {
            $("my-offers").innerHTML = `
                <div class="mutedBox">
                    Nenhuma oferta publicada por este estabelecimento.
                </div>
            `;
            return;
        }

        $("my-offers").innerHTML = offers
            .map(
                (offer) => `
                    <article class="dashboardListItem">
                        <div>
                            <strong>${escapeHTML(offer.produto)}</strong>
                            <small>
                                ${escapeHTML(offer.marca)}
                                · ${formatPrice(offer.preco)}
                            </small>
                            <small>
                                Válida até:
                                ${
                                    offer.fim
                                        ? new Intl.DateTimeFormat(
                                            "pt-BR",
                                            {
                                                dateStyle: "short",
                                                timeStyle: "short"
                                            }
                                        ).format(
                                            new Date(offer.fim)
                                        )
                                        : "sem prazo"
                                }
                            </small>
                        </div>

                        <div class="dashboardListActions">
                            <button
                                class="miniAction"
                                type="button"
                                data-edit-offer="${escapeHTML(offer.chave)}"
                            >
                                Editar
                            </button>

                            <button
                                class="miniAction dangerBtn"
                                type="button"
                                data-delete-offer="${escapeHTML(offer.chave)}"
                            >
                                Excluir
                            </button>
                        </div>
                    </article>
                `
            )
            .join("");
    }

    $("my-offers").addEventListener(
        "click",
        (event) => {
            const editButton =
                event.target.closest(
                    "[data-edit-offer]"
                );

            if (editButton) {
                const offer =
                    S.getOffersForEstablishment(
                        establishment
                    ).find(
                        (item) =>
                            item.chave ===
                            editButton.dataset.editOffer
                    );

                if (!offer) {
                    return;
                }

                const product = getMyProducts().find(
                    (item) =>
                        getProductKey(item) ===
                        offer.chave
                );

                if (product) {
                    $("offer-product").value =
                        getMyProducts().indexOf(product);

                    populateBrandSelector(
                        "offer-product",
                        "offer-brand"
                    );
                }

                $("offer-edit-key").value =
                    offer.chave;

                $("offer-price").value =
                    String(offer.preco).replace(".", ",");

                $("offer-fim").value =
                    offer.fim
                        ? new Date(offer.fim)
                            .toISOString()
                            .slice(0, 16)
                        : "";

                return;
            }

            const deleteButton =
                event.target.closest(
                    "[data-delete-offer]"
                );

            if (deleteButton) {
                if (
                    !window.confirm(
                        "Excluir esta oferta?"
                    )
                ) {
                    return;
                }

                S.deleteOffer(
                    deleteButton.dataset.deleteOffer,
                    establishment.id
                );

                renderOffers();
            }
        }
    );

    $("price-form").onsubmit = (event) => {
        event.preventDefault();

        const product = selectedProduct(
            "price-product"
        );
        const price = parseDecimal(
            $("price-value").value
        );

        if (
            !product ||
            !Number.isFinite(price) ||
            price < 0
        ) {
            showMessage(
                "price-msg",
                "Informe um preço válido.",
                "error"
            );
            return;
        }

        const updated = {
            ...product,
            preco: price
        };

        S.saveProduct({
            ...updated,
            id: product.origemCatalogo
                ? undefined
                : product.id,
            origemCatalogo: false,
            chave: getProductKey(product)
        });

        S.updatePrice(
            getProductKey(product),
            price,
            "atualização pelo estabelecimento"
        );

        showMessage(
            "price-msg",
            "Preço atualizado e histórico preservado."
        );

        $("price-value").value = "";

        renderProducts();
        populateProductSelectors();
    };

    [
        $("product-price"),
        $("offer-price"),
        $("price-value")
    ].forEach(setupDecimalInput);

    setupCNPJInput($("edit-cnpj"));
    setupCoordinateInput($("edit-coord"));

    fillEstablishment();
    renderProducts();
    populateProductSelectors();
    renderOffers();
})();
