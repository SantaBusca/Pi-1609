/* Santa Busca — persistência do protótipo. Futuramente pode ser trocada por API/banco. */
(function () {
    "use strict";

    const KEYS = {
        prices: "santaBusca:precos",
        reports: "santaBusca:relatos",
        establishments: "santaBusca:estabelecimentos",
        currentEstablishment: "santaBusca:estabelecimentoAtual",
        offers: "santaBusca:ofertas",
        points: "santaBusca:pontos",
        actions: "santaBusca:acoes",
        products: "santaBusca:produtosEstabelecimentos",
        removedProducts: "santaBusca:produtosRemovidos"
    };

    const DAY = 86400000;
    const STALE_DAYS = 30;
    const SESSION = "santaBusca:sessionId";

    function read(key, fallback) {
        try {
            const value = localStorage.getItem(key);
            return value ? JSON.parse(value) : fallback;
        } catch (error) {
            return fallback;
        }
    }

    function write(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.warn("Santa Busca: não foi possível salvar no localStorage.", error);
        }
    }

    function getSessionId() {
        let id = read(SESSION, null);

        if (!id) {
            id = `u-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
            write(SESSION, id);
        }

        return id;
    }

    function monthKey(date = new Date()) {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    }

    function priceKey(product, brand, establishment) {
        return [product, brand, establishment]
            .map((value) => String(value ?? "").trim())
            .join("|");
    }

    function normalizeText(value) {
        return String(value ?? "")
            .trim()
            .toLocaleLowerCase("pt-BR");
    }

    function sanitizeCNPJ(value) {
        return String(value ?? "")
            .replace(/\D/g, "")
            .slice(0, 14);
    }

    function formatCNPJ(value) {
        const digits = sanitizeCNPJ(value);

        if (digits.length <= 2) {
            return digits;
        }

        if (digits.length <= 6) {
            return `${digits.slice(0, 2)}.${digits.slice(2)}`;
        }

        if (digits.length <= 10) {
            return `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5)}`;
        }

        if (digits.length <= 14) {
            return `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5, 8)}/${digits.slice(8, 12)}-${digits.slice(12)}`;
        }

        return digits;
    }

    function validateCNPJ(value) {
        const digits = sanitizeCNPJ(value);

        if (digits.length !== 14 || /^(\d)\1{13}$/.test(digits)) {
            return false;
        }

        const calculateDigit = (base) => {
            let factor = base.length - 7;
            let sum = 0;

            for (const digit of base) {
                sum += Number(digit) * factor;
                factor -= 1;

                if (factor < 2) {
                    factor = 9;
                }
            }

            const remainder = sum % 11;
            return remainder < 2 ? 0 : 11 - remainder;
        };

        const firstDigit = calculateDigit(digits.slice(0, 12));
        const secondDigit = calculateDigit(`${digits.slice(0, 12)}${firstDigit}`);

        return (
            firstDigit === Number(digits[12]) &&
            secondDigit === Number(digits[13])
        );
    }

    function digitsBeforeCaret(value, caretPos) {
        return String(value ?? "")
            .slice(0, caretPos ?? 0)
            .replace(/\D/g, "")
            .length;
    }

    function caretPositionForDigitCount(formatted, digitCount) {
        let seen = 0;

        for (let i = 0; i < formatted.length; i += 1) {
            if (/\d/.test(formatted[i])) {
                seen += 1;

                if (seen === digitCount) {
                    return i + 1;
                }
            }
        }

        return formatted.length;
    }

    function reformatKeepingCaret(input, formatter) {
        const previousCaret = input.selectionStart;
        const digitCount = digitsBeforeCaret(input.value, previousCaret);

        input.value = formatter(input.value);

        const newCaret = caretPositionForDigitCount(
            input.value,
            digitCount
        );

        input.setSelectionRange(newCaret, newCaret);
    }

    function sanitizeDecimal(value, allowNegative = false) {
        let text = String(value ?? "").replace(/[^\d,.-]/g, "");

        if (!allowNegative) {
            text = text.replace(/-/g, "");
        } else {
            text = text.replace(/(?!^)-/g, "");
        }

        text = text.replace(/,/g, ".");
        const firstDot = text.indexOf(".");

        if (firstDot !== -1) {
            text =
                text.slice(0, firstDot + 1) +
                text.slice(firstDot + 1).replace(/\./g, "");
        }

        return text;
    }

    function isValidCoordinatePair(value) {
        const parts = String(value ?? "")
            .split(",")
            .map((part) => sanitizeDecimal(part, true).trim());

        if (parts.length !== 2 || parts.some((part) => part === "")) {
            return false;
        }

        const lat = Number(parts[0]);
        const lon = Number(parts[1]);

        return (
            Number.isFinite(lat) &&
            Number.isFinite(lon) &&
            lat >= -90 &&
            lat <= 90 &&
            lon >= -180 &&
            lon <= 180
        );
    }

    function ensurePriceMeta(key, basePrice) {
        const all = read(KEYS.prices, {});

        if (!all[key]) {
            const now = new Date().toISOString();

            all[key] = {
                unidade: "unidade",
                atualizadoEm: now,
                historico: [
                    {
                        preco: Number(basePrice),
                        data: now,
                        origem: "cadastro inicial"
                    }
                ],
                confirmacoes: 0,
                denuncias: 0,
                notaEventos: []
            };

            write(KEYS.prices, all);
        }

        return all[key];
    }

    function savePriceMeta(key, meta) {
        const all = read(KEYS.prices, {});
        all[key] = meta;
        write(KEYS.prices, all);
    }

    function currentNormalPrice(meta, fallback) {
        const history = Array.isArray(meta?.historico) ? meta.historico : [];

        if (!history.length) {
            return Number(fallback);
        }

        const last = history[history.length - 1];
        return Number.isFinite(Number(last.preco))
            ? Number(last.preco)
            : Number(fallback);
    }

    function activeOffer(key) {
        const all = read(KEYS.offers, {});
        const offer = all[key];

        if (!offer) {
            return null;
        }

        const now = Date.now();
        const start = offer.inicio
            ? new Date(offer.inicio).getTime()
            : -Infinity;
        const end = offer.fim
            ? new Date(offer.fim).getTime()
            : Infinity;

        return now >= start &&
            now <= end &&
            Number.isFinite(Number(offer.preco))
            ? offer
            : null;
    }

    function effectivePrice(key, normalPrice) {
        const offer = activeOffer(key);
        return offer ? Number(offer.preco) : Number(normalPrice);
    }

    function isStale(meta) {
        if (!meta?.atualizadoEm) {
            return true;
        }

        return (
            Date.now() - new Date(meta.atualizadoEm).getTime() >
            STALE_DAYS * DAY
        );
    }

    function getMonthlyStats() {
        const currentMonth = monthKey();
        const events = read(KEYS.points, { events: [] }).events || [];
        const mine = events.filter(
            (event) =>
                event.usuario === getSessionId() &&
                event.mes === currentMonth
        );

        return {
            month: currentMonth,
            points: mine.reduce(
                (sum, event) => sum + Number(event.quantidade || 0),
                0
            ),
            reports: mine.filter((event) => event.tipo === "denuncia").length,
            confirmations: mine.filter(
                (event) => event.tipo === "confirmacao"
            ).length,
            contributions: mine.filter((event) =>
                ["denuncia", "confirmacao"].includes(event.tipo)
            ).length
        };
    }

    function addPoint(amount, reason, type) {
        const data = read(KEYS.points, { events: [] });
        data.events = Array.isArray(data.events) ? data.events : [];

        const event = {
            id: `p-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
            usuario: getSessionId(),
            mes: monthKey(),
            quantidade: Number(amount || 0),
            motivo: reason,
            tipo: type || "outro",
            data: new Date().toISOString()
        };

        data.events.push(event);
        write(KEYS.points, data);

        return event;
    }

    function canAct(key, action) {
        const actions = read(KEYS.actions, []);
        const currentMonth = monthKey();
        const user = getSessionId();

        return !actions.some(
            (item) =>
                item.usuario === user &&
                item.chave === key &&
                item.acao === action &&
                item.mes === currentMonth
        );
    }

    function markAction(key, action) {
        const actions = read(KEYS.actions, []);

        actions.push({
            usuario: getSessionId(),
            chave: key,
            acao: action,
            mes: monthKey(),
            data: new Date().toISOString()
        });

        write(KEYS.actions, actions);
    }

    function registerNoteAction(key, action) {
        if (!canAct(key, action)) {
            return {
                ok: false,
                reason: "duplicada",
                meta: ensurePriceMeta(key, 0)
            };
        }

        const meta = ensurePriceMeta(key, 0);

        if (action === "confirmar") {
            meta.confirmacoes = Number(meta.confirmacoes || 0) + 1;
        }

        savePriceMeta(key, meta);
        markAction(key, action);

        addPoint(
            action === "confirmar" ? 2 : 1,
            action === "confirmar"
                ? "Confirmação de preço"
                : "Denúncia de informação",
            action === "confirmar" ? "confirmacao" : "denuncia"
        );

        return {
            ok: true,
            meta
        };
    }

    function reportPrice(payload) {
        if (!canAct(payload.chave, "denuncia")) {
            return {
                ok: false,
                reason: "duplicada"
            };
        }

        const reports = read(KEYS.reports, []);
        const now = new Date().toISOString();

        const report = {
            id: `r-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
            tipo: "preco",
            usuario: getSessionId(),
            data: now,
            mes: monthKey(),
            status: "REGISTRADO",
            confirmacoes: 0,
            ...payload,
            novoPreco: Number(payload.novoPreco),
            comprovante: payload.comprovante || null
        };

        reports.push(report);
        write(KEYS.reports, reports);

        const meta = ensurePriceMeta(payload.chave, payload.precoAtual);

        meta.denuncias = Number(meta.denuncias || 0) + 1;
        meta.notaEventos = Array.isArray(meta.notaEventos)
            ? meta.notaEventos
            : [];

        meta.notaEventos.push({
            tipo: "denuncia",
            usuario: getSessionId(),
            data: now,
            mes: monthKey(),
            comprovado: true
        });

        savePriceMeta(payload.chave, meta);
        markAction(payload.chave, "denuncia");
        addPoint(5, "Envio de denúncia de preço com comprovante", "denuncia");

        return {
            ok: true,
            report,
            meta
        };
    }

    function getMonthlyReports() {
        const currentMonth = monthKey();

        return read(KEYS.reports, []).filter((report) => {
            const date = report.data ? new Date(report.data) : null;
            return date && !Number.isNaN(date.getTime()) &&
                monthKey(date) === currentMonth;
        });
    }

    function getProductMonthlyReports(key) {
        return getMonthlyReports().filter((report) => report.chave === key);
    }

    function getProductReputation(key) {
        const reports = getProductMonthlyReports(key);
        const count = reports.length;

        if (count >= 3) {
            return {
                nivel: "Muito ruim",
                classe: "veryBad",
                pontos: 10,
                denuncias: count
            };
        }

        if (count === 2) {
            return {
                nivel: "Ruim",
                classe: "bad",
                pontos: 40,
                denuncias: count
            };
        }

        if (count === 1) {
            return {
                nivel: "Atenção",
                classe: "attention",
                pontos: 70,
                denuncias: count
            };
        }

        return {
            nivel: "Ótima",
            classe: "great",
            pontos: 100,
            denuncias: 0
        };
    }

    function getEstablishmentCategory(establishment) {
        const type = normalizeText(establishment?.tipo);

        if (type === "farmacia" || type === "farmácia") {
            return "Farmácias";
        }

        if (type === "posto" || type.includes("posto")) {
            return "Postos";
        }

        if (type === "supermercado") {
            return "Supermercados";
        }

        return "Supermercados";
    }

    function getEstablishmentProducts(establishment) {
        const name = normalizeText(establishment?.nome);
        const dynamic = read(KEYS.products, []).filter(
            (product) =>
                product.estabelecimentoId === establishment?.id ||
                normalizeText(product.estabelecimento) === name
        );

        const removed = new Set(
            read(KEYS.removedProducts, [])
                .filter(
                    (item) =>
                        item.estabelecimentoId === establishment?.id
                )
                .map((item) => item.key)
        );

        const result = [...dynamic];

        if (typeof DADOS_EMBUTIDOS !== "undefined") {
            (DADOS_EMBUTIDOS.produtos || []).forEach((product) => {
                (product.itens || []).forEach((item) => {
                    (item.mercados || []).forEach((market) => {
                        if (
                            normalizeText(market.nome) !== name ||
                            removed.has(
                                priceKey(product.nome, item.marca, market.nome)
                            )
                        ) {
                            return;
                        }

                        const key = priceKey(
                            product.nome,
                            item.marca,
                            market.nome
                        );

                        if (!result.some((item) => item.chave === key)) {
                            result.push({
                                id: `catalogo-${key}`,
                                chave: key,
                                estabelecimentoId: establishment.id,
                                estabelecimento: establishment.nome,
                                nome: product.nome,
                                marca: item.marca,
                                categoria: product.categoria,
                                unidade: "unidade",
                                preco: currentNormalPrice(
                                    ensurePriceMeta(key, market.preco),
                                    market.preco
                                ),
                                emoji: product.emoji || "📦",
                                disponibilidade: "disponivel",
                                origemCatalogo: true
                            });
                        }
                    });
                });
            });
        }

        return result;
    }

    function saveProduct(product) {
        const products = read(KEYS.products, []);
        const item = {
            ...product,
            id: product.id || `prod-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
            criadoEm: product.criadoEm || new Date().toISOString(),
            atualizadoEm: new Date().toISOString()
        };

        const index = products.findIndex((current) => current.id === item.id);

        if (index >= 0) {
            products[index] = {
                ...products[index],
                ...item
            };
        } else {
            products.push(item);
        }

        write(KEYS.products, products);
        return item;
    }

    function deleteProduct(productId, product) {
        const products = read(KEYS.products, []);
        const index = products.findIndex((item) => item.id === productId);

        if (index >= 0) {
            products.splice(index, 1);
            write(KEYS.products, products);
            return true;
        }

        if (product?.chave) {
            const removed = read(KEYS.removedProducts, []);

            if (
                !removed.some(
                    (item) =>
                        item.estabelecimentoId === product.estabelecimentoId &&
                        item.key === product.chave
                )
            ) {
                removed.push({
                    estabelecimentoId: product.estabelecimentoId,
                    key: product.chave
                });
            }

            write(KEYS.removedProducts, removed);
            return true;
        }

        return false;
    }

    function saveEstablishment(establishment) {
        const list = read(KEYS.establishments, []);
        const item = {
            ...establishment,
            cnpj: formatCNPJ(establishment.cnpj)
        };

        if (!item.id) {
            item.id = `est-${Date.now().toString(36)}`;
        }

        const index = list.findIndex(
            (current) =>
                current.id === item.id ||
                normalizeText(current.email) === normalizeText(item.email)
        );

        if (index >= 0) {
            list[index] = {
                ...list[index],
                ...item
            };
        } else {
            list.push(item);
        }

        write(KEYS.establishments, list);
        write(KEYS.currentEstablishment, item.id);

        return item;
    }

    function getEstablishments() {
        return read(KEYS.establishments, []);
    }

    function getCurrentEstablishment() {
        const id = read(KEYS.currentEstablishment, null);
        return getEstablishments().find((item) => item.id === id) || null;
    }

    function saveOffer(offer) {
        const offers = read(KEYS.offers, {});
        const key = offer.chave;

        offers[key] = {
            ...offers[key],
            ...offer,
            id: offers[key]?.id ||
                `offer-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
        };

        write(KEYS.offers, offers);
        return offers[key];
    }

    function getOffersForEstablishment(establishment) {
        return Object.values(read(KEYS.offers, {})).filter(
            (offer) =>
                offer.criadaPor === establishment?.id ||
                normalizeText(offer.estabelecimento) ===
                    normalizeText(establishment?.nome)
        );
    }

    function deleteOffer(key, establishmentId) {
        const offers = read(KEYS.offers, {});
        const offer = offers[key];

        if (
            offer &&
            (!establishmentId || offer.criadaPor === establishmentId)
        ) {
            delete offers[key];
            write(KEYS.offers, offers);
            return true;
        }

        return false;
    }

    function updatePrice(key, newPrice, origin) {
        const all = read(KEYS.prices, {});
        const meta = all[key] || ensurePriceMeta(key, newPrice);
        const now = new Date().toISOString();

        meta.atualizadoEm = now;
        meta.historico = Array.isArray(meta.historico)
            ? meta.historico
            : [];

        meta.historico.push({
            preco: Number(newPrice),
            data: now,
            origem: origin || "atualização"
        });

        savePriceMeta(key, meta);
        return meta;
    }

    function updateProductPrice(product, newPrice, origin) {
        const price = Number(newPrice);
        const key = product.chave || priceKey(
            product.nome,
            product.marca,
            product.estabelecimento
        );

        updatePrice(key, price, origin);

        if (!product.origemCatalogo && product.id) {
            const products = read(KEYS.products, []);
            const index = products.findIndex((item) => item.id === product.id);

            if (index >= 0) {
                products[index].preco = price;
                products[index].atualizadoEm = new Date().toISOString();
                write(KEYS.products, products);
            }
        }

        return price;
    }

    function getCatalogProducts(baseProducts) {
        const products = JSON.parse(JSON.stringify(baseProducts || []));
        const dynamicProducts = read(KEYS.products, []);
        const removed = read(KEYS.removedProducts, []);

        function isRemoved(establishmentId, key) {
            return removed.some(
                (item) =>
                    item.estabelecimentoId === establishmentId &&
                    item.key === key
            );
        }

        dynamicProducts.forEach((product) => {
            const key = priceKey(
                product.nome,
                product.marca,
                product.estabelecimento
            );

            if (isRemoved(product.estabelecimentoId, key)) {
                return;
            }

            let base = products.find(
                (item) =>
                    normalizeText(item.nome) === normalizeText(product.nome) &&
                    normalizeText(item.categoria) ===
                        normalizeText(product.categoria)
            );

            if (!base) {
                base = {
                    nome: product.nome,
                    emoji: product.emoji || "📦",
                    categoria: product.categoria,
                    itens: []
                };
                products.push(base);
            }

            let brand = (base.itens || []).find(
                (item) =>
                    normalizeText(item.marca) === normalizeText(product.marca)
            );

            if (!brand) {
                brand = {
                    marca: product.marca,
                    mercados: []
                };
                base.itens = base.itens || [];
                base.itens.push(brand);
            }

            const existingMarket = (brand.mercados || []).find(
                (market) =>
                    normalizeText(market.nome) ===
                    normalizeText(product.estabelecimento)
            );

            if (existingMarket) {
                existingMarket.preco = product.preco;
                existingMarket.unidade = product.unidade || "unidade";
                existingMarket.disponibilidade =
                    product.disponibilidade || "disponivel";
            } else {
                brand.mercados.push({
                    nome: product.estabelecimento,
                    preco: Number(product.preco),
                    unidade: product.unidade || "unidade",
                    disponibilidade: product.disponibilidade || "disponivel"
                });
            }

            const meta = read(KEYS.prices, {})[key];

            if (meta) {
                const current = currentNormalPrice(meta, product.preco);
                const market = brand.mercados.find(
                    (item) =>
                        normalizeText(item.nome) ===
                        normalizeText(product.estabelecimento)
                );

                if (market) {
                    market.preco = current;
                }
            }
        });

        removed.forEach((item) => {
            products.forEach((product) => {
                (product.itens || []).forEach((brand) => {
                    brand.mercados = (brand.mercados || []).filter(
                        (market) =>
                            priceKey(
                                product.nome,
                                brand.marca,
                                market.nome
                            ) !== item.key ||
                            item.estabelecimentoId !==
                                findEstablishmentIdByName(market.nome)
                    );
                });
            });
        });

        return products;
    }

    function findEstablishmentIdByName(name) {
        const establishment = getEstablishments().find(
            (item) => normalizeText(item.nome) === normalizeText(name)
        );

        return establishment?.id || null;
    }

    function getAllRankingEstablishments() {
        const establishments = getEstablishments();
        const result = establishments.map((item) => ({
            id: item.id,
            nome: item.nome,
            tipo: item.tipo,
            categoria: getEstablishmentCategory(item)
        }));

        if (typeof DADOS_EMBUTIDOS !== "undefined") {
            (DADOS_EMBUTIDOS.categorias || []).forEach((category) => {
                (category.locais || []).forEach((place) => {
                    if (
                        !result.some(
                            (item) =>
                                normalizeText(item.nome) ===
                                normalizeText(place.nome)
                        )
                    ) {
                        result.push({
                            id: `catalogo-${place.nome}`,
                            nome: place.nome,
                            tipo: category.nome,
                            categoria: category.nome
                        });
                    }
                });
            });
        }

        return result;
    }

    function getEstablishmentReputation() {
        const establishments = getAllRankingEstablishments();
        const reports = getMonthlyReports();

        return establishments.map((establishment) => {
            const establishmentReports = reports.filter(
                (report) =>
                    normalizeText(report.estabelecimento) ===
                    normalizeText(establishment.nome)
            );

            const productCounts = {};

            establishmentReports.forEach((report) => {
                const key = report.chave || priceKey(
                    report.produto,
                    report.marca,
                    report.estabelecimento
                );

                if (!productCounts[key]) {
                    productCounts[key] = {
                        count: 0,
                        produto: report.produto || ""
                    };
                }

                productCounts[key].count += 1;
            });

            let worst = {
                nivel: "Ótima",
                pontos: 100,
                denuncias: 0,
                produto: ""
            };

            Object.values(productCounts).forEach((product) => {
                const count = product.count;
                const nivel =
                    count >= 3
                        ? "Muito ruim"
                        : count === 2
                            ? "Ruim"
                            : count === 1
                                ? "Atenção"
                                : "Ótima";
                const pontos =
                    count >= 3
                        ? 10
                        : count === 2
                            ? 40
                            : count === 1
                                ? 70
                                : 100;

                if (pontos < worst.pontos) {
                    worst = {
                        nivel,
                        pontos,
                        denuncias: count,
                        produto: product.produto
                    };
                }
            });

            return {
                ...establishment,
                nivel: worst.nivel,
                reputacaoPontos: worst.pontos,
                produtoCritico: worst.produto,
                denunciasProduto: worst.denuncias,
                denuncias: establishmentReports.length
            };
        });
    }

    function getEstablishmentRanking() {
        return getEstablishmentReputation()
            .map((establishment) => {
                const penalty = Math.max(0, establishment.denuncias - 3);

                return {
                    ...establishment,
                    penalizacao: penalty,
                    pontos: Math.max(0, 100 - penalty)
                };
            })
            .sort(
                (a, b) =>
                    b.pontos - a.pontos ||
                    b.denuncias - a.denuncias ||
                    a.nome.localeCompare(b.nome, "pt-BR")
            );
    }

    function getContributorTier() {
        const points = getMonthlyStats().points;

        if (points >= 30) {
            return {
                label: "Colaborador destaque"
            };
        }

        if (points >= 15) {
            return {
                label: "Colaborador ativo"
            };
        }

        if (points >= 5) {
            return {
                label: "Colaborador"
            };
        }

        return {
            label: "Novo colaborador"
        };
    }

    function getOfferNotifications() {
        const stats = getMonthlyStats();

        if (!stats.contributions) {
            return [];
        }

        const offers = read(KEYS.offers, {});
        const now = Date.now();

        return Object.values(offers)
            .filter((offer) => {
                const end = offer.fim
                    ? new Date(offer.fim).getTime()
                    : Infinity;

                return end >= now;
            })
            .map((offer) => ({
                ...offer,
                prioridade:
                    stats.points >= 15 ? "primeira_mão" : "liberada"
            }));
    }

    function getUserRanking() {
        const currentMonth = monthKey();
        const events = read(KEYS.points, { events: [] }).events || [];
        const me = getSessionId();
        const totals = {};

        events
            .filter((event) => event.mes === currentMonth)
            .forEach((event) => {
                totals[event.usuario] =
                    Number(totals[event.usuario] || 0) +
                    Number(event.quantidade || 0);
            });

        const collaborators = Object.keys(totals)
            .map((user) => ({
                usuario: user,
                voce: user === me,
                pontos: totals[user]
            }))
            .sort((a, b) => b.pontos - a.pontos);

        return {
            mes: currentMonth,
            colaboradores: collaborators
        };
    }

    function getAchievements() {
        const me = getSessionId();
        const actions = read(KEYS.actions, []).filter(
            (action) => action.usuario === me
        );
        const events = (read(KEYS.points, { events: [] }).events || []).filter(
            (event) => event.usuario === me
        );

        const total = actions.length;
        const confirmations = actions.filter(
            (action) => action.acao === "confirmar"
        ).length;
        const reports = actions.filter(
            (action) => action.acao === "denuncia"
        ).length;
        const months = new Set(actions.map((action) => action.mes)).size;
        const totalPoints = events.reduce(
            (sum, event) => sum + Number(event.quantidade || 0),
            0
        );

        return [
            {
                id: "primeira",
                titulo: "Primeira contribuição",
                descricao:
                    "Confirme ou denuncie um preço pela primeira vez.",
                desbloqueada: total >= 1
            },
            {
                id: "verificador",
                titulo: "Verificador dedicado",
                descricao: "Confirme preços 3 vezes.",
                desbloqueada: confirmations >= 3,
                progresso: `${Math.min(confirmations, 3)}/3`
            },
            {
                id: "fiscal",
                titulo: "Fiscal de preços",
                descricao: "Envie 3 denúncias com comprovante.",
                desbloqueada: reports >= 3,
                progresso: `${Math.min(reports, 3)}/3`
            },
            {
                id: "assiduo",
                titulo: "Colaborador assíduo",
                descricao:
                    "Contribua em pelo menos 2 meses diferentes.",
                desbloqueada: months >= 2,
                progresso: `${Math.min(months, 2)}/2`
            },
            {
                id: "destaque",
                titulo: "Colaborador destaque",
                descricao: "Acumule 30 pontos ou mais no total.",
                desbloqueada: totalPoints >= 30,
                progresso: `${Math.min(totalPoints, 30)}/30`
            }
        ];
    }

    window.SantaBuscaStorage = {
        KEYS,
        STALE_DAYS,
        read,
        write,
        getSessionId,
        monthKey,
        priceKey,
        normalizeText,
        sanitizeCNPJ,
        formatCNPJ,
        validateCNPJ,
        reformatKeepingCaret,
        sanitizeDecimal,
        isValidCoordinatePair,
        ensurePriceMeta,
        currentNormalPrice,
        activeOffer,
        effectivePrice,
        isStale,
        getMonthlyStats,
        addPoint,
        registerNoteAction,
        reportPrice,
        getMonthlyReports,
        getProductMonthlyReports,
        getProductReputation,
        getEstablishmentCategory,
        getEstablishmentProducts,
        saveProduct,
        deleteProduct,
        getCatalogProducts,
        getEstablishments,
        saveEstablishment,
        getCurrentEstablishment,
        saveOffer,
        getOffersForEstablishment,
        deleteOffer,
        updatePrice,
        updateProductPrice,
        canAct,
        getAllRankingEstablishments,
        getEstablishmentReputation,
        getEstablishmentRanking,
        getContributorTier,
        getOfferNotifications,
        getUserRanking,
        getAchievements
    };
})();
