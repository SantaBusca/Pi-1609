# Santa Busca — versão integrada

Esta versão trabalha em cima da estrutura original do Santa Busca e adiciona as melhorias solicitadas sem substituir a interface por um projeto novo.

## O que foi preservado

- Identidade visual, cores, fontes, botões e estrutura geral.
- Categorias Supermercados, Farmácias e Postos.
- Pesquisa de produtos e estabelecimentos.
- Localização e ordenação por preço/distância.
- Comparação de preços.
- Confirmação de preço.
- Denúncia de preço com comprovante obrigatório.
- Histórico de preços.
- Pontos mensais.
- Notificações e ofertas.
- Ranking e conquistas do usuário.
- Reputação automática dos estabelecimentos.
- Área de estabelecimento separada do painel.
- localStorage como armazenamento do protótipo.

## Alterações desta versão

### Página inicial

A barra de pesquisa agora aparece antes da seção de categorias.

A estrutura continua usando as mesmas áreas existentes:
- `.controlsPanel` para pesquisa/localização.
- `.categorySection` para as três categorias.

A mãozinha `👆` da `.emptyHero`, criada dentro de `render()` em `script.js`, foi mantida separada dos emojis das categorias e recebe somente um movimento visual para orientar o usuário para a área das categorias.

### Estabelecimento

O cadastro e o login continuam em `estabelecimento.html`.

Após cadastro ou login, o estabelecimento é enviado para:

`dashboard-estabelecimento.html`

O dashboard é protegido: sem uma sessão de estabelecimento em `localStorage`, o acesso volta para `estabelecimento.html`.

O painel permite:
- visualizar dados cadastrados;
- editar dados;
- visualizar logo/foto;
- cadastrar produtos;
- editar produtos;
- alterar preço;
- alterar disponibilidade;
- excluir produtos;
- publicar ofertas;
- editar/excluir ofertas;
- sair da conta.

Os produtos novos são persistidos em `localStorage` e entram no catálogo da página principal sem criar produtos fictícios.

### CNPJ

O CNPJ agora possui validação real dos dígitos verificadores.

O campo:
- aceita somente números durante a entrada;
- aplica a máscara `00.000.000/0000-00`;
- remove letras e caracteres indevidos quando digitados ou colados;
- valida a quantidade de 14 dígitos;
- rejeita sequências inválidas como todos os dígitos iguais;
- valida novamente no envio do cadastro;
- também é validado no formulário de edição do dashboard.

O exemplo `12345678000195` é formatado como `12.345.678/0001-95`.

### Outros campos numéricos

A validação respeita o tipo de cada campo.

- Preços: números e separador decimal.
- Coordenadas: números, decimais e sinal negativo.
- CNPJ: máscara e validação própria.
- Nome/endereço: continuam aceitando letras e números quando apropriado.
- E-mail: validação própria de e-mail.

### Pontos

As ações do usuário comum continuam com:
- Confirmar preço → +2 pontos.
- Denunciar preço com comprovante → +5 pontos.

A pontuação é mensal e a mesma ação para o mesmo preço fica bloqueada no mesmo mês.

Estabelecimentos não recebem pontos nem participam do ranking de colaboradores.

### Reputação

A reputação é calculada automaticamente com as denúncias do mês atual:

- 0 → Ótima
- 1 → Atenção
- 2 → Ruim
- 3 ou mais → Muito ruim

A reputação geral de um estabelecimento considera o pior produto denunciado.

### Ranking dos estabelecimentos

O ranking não possui limite fixo de três estabelecimentos.

Todos os estabelecimentos existentes nos dados do sistema aparecem automaticamente, incluindo novos estabelecimentos cadastrados.

A penalização considera o total de denúncias do estabelecimento no mês atual, somando denúncias de todos os produtos.

Regra:

- 0 denúncias → 0 pontos perdidos.
- 1 denúncia → 0 pontos perdidos.
- 2 denúncias → 0 pontos perdidos.
- 3 denúncias → 0 pontos perdidos.
- 4 denúncias → -1 ponto.
- 5 denúncias → -2 pontos.
- 6 denúncias → -3 pontos.

A fórmula usada é:

`pontos perdidos = max(0, denúncias do mês - 3)`

A pontuação exibida no ranking parte de 100 e desconta somente essa penalização.

Isso é separado da reputação do produto. Portanto, um produto pode ficar com reputação "Muito ruim" a partir da 3ª denúncia, enquanto o estabelecimento ainda não perde pontos no ranking até ultrapassar a 3ª denúncia total.

### Correção de bug crítico (23/09/2026)

Foi encontrado e corrigido um erro fatal de JavaScript que quebrava
`estabelecimento.html` e, por consequência, `dashboard-estabelecimento.html`
(que redireciona para `estabelecimento.html` quando não há sessão):
a função `dropdown()` recebia o **id em texto** do painel (ex.:
`"dias-panel"`) mas tentava chamar `panel.appendChild(...)` diretamente
nessa string, gerando `panel.appendChild is not a function` assim que a
página carregava. Isso interrompia a execução do script inteiro,
quebrando login, cadastro e o dashboard como um todo — mesmo com o
restante do código correto.

Corrigido resolvendo o elemento real (`const panelEl = $(panel)`) antes
de usá-lo. Testado abrindo as páginas de verdade em um navegador
(Playwright/Chromium), simulando clique a clique: cadastro completo do
estabelecimento (com seleção de dias/tipo pelo dropdown), login,
redirecionamento para o dashboard, cadastro de produto e conferência de
que o produto aparece no catálogo do `index.html` e no ranking dinâmico.
Também foi corrigido o "pulo do cursor" no campo de CNPJ ao digitar/editar
no meio do valor.

### Formatação e revisão

Os arquivos HTML, CSS, JavaScript e JSON foram reorganizados em várias linhas com indentação para facilitar leitura e manutenção.

Foi feita verificação de sintaxe com `node --check` nos arquivos JavaScript.

Também foi feita uma simulação da camada de armazenamento para verificar:
- CNPJ válido/inválido;
- persistência de estabelecimento;
- persistência de produto;
- inclusão de produto no catálogo;
- reputação mensal;
- soma de denúncias por estabelecimento;
- tolerância de 3 denúncias;
- penalização do ranking.

A interface não foi executada em um navegador real neste ambiente, portanto testes visuais de clique, upload e geolocalização ainda devem ser feitos localmente ao abrir o projeto.
